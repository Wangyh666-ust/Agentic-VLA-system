"""User's two-question checker; no simulator object truth enters the model."""
import json
import hashlib
from pathlib import Path
from . import vision


def build_prompt(context):
    task = context['current_subtask']
    safe = {
        'user_request': context['user_request'],
        'current_subtask': {k: task.get(k) for k in ('operation', 'target', 'destination')},
        'desired_state': context.get('criteria', {}).get('desired_state'),
        'sensor_frames': context['sensor_frames'],
        'actuator_measurements': context['actuator_measurements'],
    }
    return '\n'.join([
        '你是机器人子任务检查器。根据当前照片和同步夹爪编码器，只回答两个问题。',
        '1. goal_achieved：根据当前子任务描述，指定物品是否已经在目的地位置，或要求的开关状态是否已经达到？这决定是否停止VLA并交给收尾器。物品已在目标位置但手还夹着，也可以为true；松手、退离由收尾器完成。不要增加支撑证明、精确姿态或其他任务未要求的条件。',
        '2. holding_or_contact：夹爪是否仍夹持或接触当前目标？结合照片和编码器判断。闭合不独自证明持物；达到标准开口也不独自证明手已离开目标。',
        '两问独立判断。看不清返回null，不猜测。开火看当前炉圈或旋钮状态，红色发热炉圈表示已开火。',
        '只输出JSON：{"goal_achieved":true或false或null,"holding_or_contact":true或false或null,"reason":"简短画面依据"}。',
        json.dumps(safe, ensure_ascii=False),
    ])


class SimpleQwenClient(vision.QwenClient):
    simple_handoff = True

    def record_response(self, context, image_paths, prompt, request_bytes, raw, index, status):
        directory = Path(self.audit_dir)
        directory.mkdir(parents=True, exist_ok=True)
        (directory / f'call_{index:02d}_response.json').write_bytes(raw)
        record = {'prompt': prompt, 'context': context, 'http_status': status,
                  'request_sha256': hashlib.sha256(request_bytes).hexdigest(),
                  'images': [{'path': str(path), 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()} for path in image_paths]}
        (directory / f'call_{index:02d}_request.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def parse_verdict(self, content):
        raw = vision._parse_verdict_content(content)
        goal, contact = raw.get('goal_achieved'), raw.get('holding_or_contact')
        for name, value in [('goal_achieved', goal), ('holding_or_contact', contact)]:
            if value is not None and type(value) is not bool:
                raise ValueError(name + ' must be bool or null')
        reason = raw.get('reason', '')
        if not isinstance(reason, str):
            raise ValueError('reason must be string')
        # Legacy interface aliases, NOT separate model observations. No support gate.
        verdict = {key: None for key in vision._BOOL_FIELDS}
        verdict.update(operation_achieved=goal, at_destination=goal,
                       released=None if contact is None else not contact,
                       clear_of_target=None if contact is None else not contact,
                       boxes={}, evidence=[reason], unknown_reasons=[])
        self.last_two_question_verdict = raw
        return verdict

    def analyze(self, context, image_paths):
        prompt = build_prompt(context)
        result = self._request(context, image_paths, prompt)
        result['prompt_text'] = prompt
        result['checker'] = 'two_question_goal_contact_v2'
        result['two_question_verdict'] = self.last_two_question_verdict
        return result


def goal_achieved(context, verdict):
    return verdict.get('operation_achieved') is True


def reconcile(context, verdict, robot, reference):
    out = vision.validate_verdict(verdict)
    measurements = context['actuator_measurements']
    latest = max(f['timestamp'] for f in context['sensor_frames'])
    if abs(measurements['timestamp'] - latest) > 1e-9:
        raise ValueError('encoder and image timestamps differ')
    for key, values in (('finger_qpos', robot['finger_qpos']),
                        ('standard_open_finger_qpos', reference['finger_home'])):
        if len(values) != 2 or any(abs(float(a) - float(b)) > 1e-9 for a, b in zip(measurements[key], values)):
            raise ValueError('encoder/reference mismatch')
    opened = max(abs(float(a) - float(b)) for a, b in zip(robot['finger_qpos'], reference['finger_home'])) <= .002
    if not opened:
        out['released'] = False
        out['clear_of_target'] = False
        out['evidence'].append('夹爪尚未达到标准开口，需要发出开爪命令；不据此推断物品未到位或仍被持有。')
    return out


def decide(context, verdict):
    achieved = verdict.get('operation_achieved')
    if achieved is None:
        return vision._decision('unknown', 'subtask purpose unknown')
    if not goal_achieved(context, verdict):
        return vision._decision('incomplete', 'subtask purpose not achieved')
    if verdict.get('released') is not True:
        return vision._decision('needs_release', 'purpose achieved; open fingers', allow_release=True)
    if verdict.get('clear_of_target') is not True:
        return vision._decision('needs_retreat', 'purpose achieved; withdraw hand', allow_retreat=True)
    return vision._decision('complete', 'purpose achieved and hand separated')
