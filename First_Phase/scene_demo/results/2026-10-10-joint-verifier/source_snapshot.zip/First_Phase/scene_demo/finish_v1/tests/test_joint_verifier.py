import copy
import unittest
from unittest import mock
from scene_demo.finish_v1 import vision
from scene_demo.finish_v1.tests.test_runtime import RuntimeTests, ALL_TRUE

class JointVerifierTests(RuntimeTests):
    def strict(self):
        ctx=copy.deepcopy(self.context)
        ctx['sensor_frames']=[{'frame':0,'view':'agentview','timestamp':1.0}]
        ctx['actuator_measurements']={'timestamp':1.0,'stage':'post_execution','finger_qpos':[0.04,-0.04],'standard_open_finger_qpos':[0.04,-0.04],'max_abs_arm_qvel':0.0}
        return ctx

    def test_timestamp_mismatch_http_zero(self):
        ctx=self.strict();ctx['actuator_measurements']['timestamp']=2.0
        client=vision.QwenClient(max_calls=1)
        with mock.patch('urllib.request.urlopen') as http:
            with self.assertRaises(ValueError): client.analyze(ctx, [])
            http.assert_not_called()
        self.assertEqual(client._calls,0)

    def test_missing_timestamp_and_mismatched_robot_unknown(self):
        for mode in ('missing','robot'):
            ctx=self.strict();robot={'finger_qpos':[0.04,-0.04]}
            if mode=='missing':del ctx['actuator_measurements']['timestamp']
            else:robot['finger_qpos']=[0.0,0.0]
            fused=vision.reconcile_verdict(ctx,ALL_TRUE,robot,self.reference)
            self.assertIsNone(fused['released'])
            self.assertEqual(vision.decide(ctx,fused)['state'],'unknown')
            self.assertIn('missing_or_stale_encoder',fused['unknown_reasons'])

    def test_closed_raw_complete_and_open_unknown_and_negative(self):
        ctx=self.strict();ctx['actuator_measurements']['finger_qpos']=[0.0,0.0]
        fused=vision.reconcile_verdict(ctx,ALL_TRUE,{'finger_qpos':[0.0,0.0]},self.reference)
        decision=vision.decide(ctx,fused)
        self.assertEqual(decision['state'],'needs_release');self.assertTrue(decision['allow_release'])
        ctx=self.strict();raw=copy.deepcopy(ALL_TRUE);raw['released']=None
        fused=vision.reconcile_verdict(ctx,raw,{'finger_qpos':[0.04,-0.04]},self.reference)
        self.assertIsNone(fused['released'])
        raw['at_destination']=False
        self.assertEqual(vision.decide(ctx,vision.reconcile_verdict(ctx,raw,{'finger_qpos':[0.04,-0.04]},self.reference))['state'],'incomplete')

    def test_captured_feedback_without_later_read(self):
        mon=self.monitor();self.record_pair(mon)
        mon.port.read_robot=lambda: (_ for _ in ()).throw(AssertionError('late read forbidden'))
        mon._check(self.context,[])
        ctx,_=mon.call_client.calls[-1]
        self.assertEqual(ctx['actuator_measurements']['timestamp'],10.0)
        self.assertEqual(ctx['actuator_measurements']['finger_qpos'],[0.04,-0.04])

    def test_missing_captured_feedback_zero_model_actions(self):
        mon=self.monitor();self.record_pair(mon);capture=mon.port.capture
        def missing():
            cap=capture();del cap['robot'];return cap
        mon.port.capture=missing
        with self.assertRaisesRegex(RuntimeError,'missing robot'):mon._check(self.context,[])
        self.assertEqual(mon.calls,0);self.assertEqual(mon.port.steps,0)

if __name__=='__main__':unittest.main()
