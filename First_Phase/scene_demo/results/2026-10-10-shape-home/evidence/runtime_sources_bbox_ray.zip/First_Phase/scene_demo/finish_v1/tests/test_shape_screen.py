"""GPT fixed OBB and projection acceptance, worker mechanical implementation."""
import unittest
import numpy as np
from scene_demo.finish_v1 import geometry, vision
from scene_demo.finish_v1.tests.test_takeover_vision import _place_context, _verdict


def box(center=(0, 0, 0), half=(.1, .01, .01), angle=0):
    c, s = np.cos(angle), np.sin(angle)
    return {"id": "hand", "center": list(center), "half_extents": list(half), "rotation": [[c, -s, 0], [s, c, 0], [0, 0, 1]], "hand": True}


class ShapeScreenTests(unittest.TestCase):
    def test_thin_rotated_box_outside_obb_inside_rbound(self):
        shape = box(angle=np.pi/2)
        points = np.array([[.06, 0, 0]])
        self.assertLess(np.linalg.norm(points[0]), np.linalg.norm(shape["half_extents"]))
        np.testing.assert_allclose(geometry.shape_distance(points, shape), [.05])
        self.assertTrue(geometry.screen_shapes(points, [shape], [[shape]])["ok"])

    def test_path_entering_obstacle_rejected(self):
        start = box(half=(.01, .01, .01))
        end = box(center=(.05, 0, 0), half=(.01, .01, .01))
        report = geometry.screen_shapes(np.array([[.05, 0, 0]]), [start], [[end]])
        self.assertFalse(report["ok"])
        self.assertEqual(report["reason"], "path_margin_violation")

    def test_rotation_changes_clearance(self):
        points = np.array([[.06, 0, 0]])
        self.assertLess(geometry.shape_distance(points, box())[0], 0)
        np.testing.assert_allclose(geometry.shape_distance(points, box(angle=np.pi/2)), [.05])

    def test_inside_obstacle_kept_with_hand_diagnostic(self):
        shape = box()
        report = geometry.screen_shapes(np.zeros((1, 3)), [shape], [[shape]])
        self.assertFalse(report["ok"])
        self.assertFalse(report["endpoint_hand_clear"])
        self.assertEqual(report["diagnostic"]["geom"], "hand")
        self.assertLess(report["diagnostic"]["current_clearance"], 0)
        self.assertIn("no OBB point deletion", report["diagnostic"]["self_mask_policy"])

    def test_invalid_rotation_bounds_and_margin_rejected(self):
        points = np.array([[1., 1., 1.]])
        invalid = box()
        invalid["rotation"] = [[2, 0, 0], [0, 1, 0], [0, 0, 1]]
        self.assertEqual(geometry.screen_shapes(points, [invalid], [[invalid]])["reason"], "invalid_start_shape")
        missing = box()
        del missing["half_extents"]
        self.assertEqual(geometry.screen_shapes(points, [box()], [[missing]])["reason"], "invalid_path_shape")
        for margin in (-.1, float("nan")):
            self.assertEqual(geometry.screen_shapes(points, [box()], [[box()]], margin)["reason"], "invalid_margin")

    def test_projection_overlap_preserves_true_and_null(self):
        boxes = {"front": {name: [.1, .1, .2, .2] for name in ("target", "destination", "gripper")}}
        for raw_clear in (True, None):
            result = vision.reconcile_verdict(_place_context(), _verdict(clear_of_target=raw_clear, boxes=boxes), {"finger_qpos": [.04, -.04]}, {"finger_home": [.04, -.04]})
            self.assertIs(result["clear_of_target"], raw_clear)
            self.assertIn("2D projection overlap near target/support; not 3D contact evidence", result["evidence"])


if __name__ == "__main__":
    unittest.main()
